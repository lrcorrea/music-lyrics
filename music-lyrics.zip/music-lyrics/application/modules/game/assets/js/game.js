$(document).ready(function() {
    var xhr = false,
        duration,
        music = document.getElementById('song'),
        $lyrics = $('.lyrics .content'),
        time = 0,
        currentTimeFormated = 0,
        trecho = 1;

    music.addEventListener("timeupdate", timeUpdate, false);

    function timeUpdate() {
        currentTimeFormated = parseInt(music.currentTime);

        console.log(currentTimeFormated, trecho, music.currentTime);
        $('#input input').prop('disabled', true);
        //trecho 1
        if(currentTimeFormated == 43 && trecho == 1){
            console.log('pause' + music.currentTime);
            music.pause();
            $('#input input').focus().prop('disabled', false).attr('disabled', false);
            $('#input input').focus();
        }

        //trecho 2
        if(currentTimeFormated == 47 && music.currentTime > 47.58 && trecho == 2){
        // if(currentTimeFormated == 45 && music.currentTime > 45.5 && trecho == 2){
            console.log('pause' + music.currentTime);
            music.pause();
            $('#input input').focus().prop('disabled', false).attr('disabled', false);
        }

        //trecho 3
        if(currentTimeFormated == 57 && music.currentTime > 57.5 && trecho == 3){
            console.log('pause' + music.currentTime);
            music.pause();
            $('#input input').focus().prop('disabled', false).attr('disabled', false);
        }

        var playPercent = 100 * (music.currentTime / duration);
        if(music.currentTime < 35){
            time = time+2;
            // time = music.currentTime*10;
        }else if(music.currentTime > 35 && music.currentTime < 40){
            time = time+.6;
        }else{
            time = time+3.5;
        }

        $lyrics.css({"transform":"translateY(-"+(time)+"px)"});
        // console.log(playPercent);
    }

    // Gets audio file duration
    music.addEventListener("canplaythrough", function () {
        duration = music.duration;
    }, false);

    $('form').on('submit', function(event) {
        event.preventDefault();

        if($('#input input').attr('disabled')){
            return false;
        }

        if(xhr) return false;

        xhr = $.ajax({
            url: base_url + 'game/verify_word',
            type: 'POST',
            dataType: 'json',
            data: {res: $('#input input').val(), trecho: trecho},
            beforeSend: function(){
                // $('.form .submit').addClass('loading');
            },
            complete: function(){
                xhr = false;
                // $('.form .submit').removeClass('loading');
            },
            success: function(data){
                if(data.status && data.is_valid){
                    if(trecho == 1){
                        $('.lyrics .content span:eq('+trecho+')')[0].html('maluquez');
                    } else if(trecho == 2){
                        $('.lyrics .content span:eq('+trecho+')')[0].html('lucidez');
                    }else if(trecho == 2){
                        $('.lyrics .content span:eq('+trecho+')')[0].html('beleza');
                    }
                    $('#input input').val('');
                    trecho++;
                    music.play();
                }
            },
            error: function(){
                console.log('error');
            },
        });
    });
});